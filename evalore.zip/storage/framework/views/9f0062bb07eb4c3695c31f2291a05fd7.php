

<?php $__env->startSection('title', 'Our Ingredients | Evalore'); ?>

<?php $__env->startSection('content'); ?>

<main class="ev-ingredients-page">

    <!-- HERO -->
    <section class="ev-ing-hero">
        <div class="ev-ing-hero-image"></div>
        <div class="ev-ing-hero-overlay"></div>

        <div class="ev-ing-hero-content">
            <span class="ev-ing-eyebrow">THE BOTANICAL EDIT</span>

            <h1>Inspired by Nature.<br>
                <em>Selected with Care.</em>
            </h1>

            <div class="ev-ing-line"></div>

            <p>
                Discover the ingredients that inspire<br>
                the Evaloré approach to beauty.
            </p>
        </div>

        <div class="ev-ing-hero-bottom">
            <span>OUR INGREDIENTS</span>
            <span>THE ART OF INGREDIENTS</span>
        </div>
    </section>


    <!-- INTRODUCTION -->
    <section class="ev-ing-intro">
        <div class="ev-ing-intro-inner">

            <span class="ev-ing-kicker">A THOUGHTFUL APPROACH</span>

            <h2>Every ingredient has<br>
                <em>a story to tell.</em>
            </h2>

            <div class="ev-ing-gold-line"></div>

            <p>
                At Evaloré, ingredients are central to our beauty philosophy.
                We draw inspiration from botanical traditions and combine
                selected plant extracts with familiar cosmetic ingredients
                to create thoughtful skincare and body-care experiences.
            </p>

            <span class="ev-ing-intro-signature">
                Nature-inspired care, thoughtfully considered.
            </span>

        </div>
    </section>


    <!-- ALOE VERA -->
    <section class="ev-ing-feature ev-ing-aloe">

        <div class="ev-ing-feature-image">
            <img src="<?php echo e(asset('assets/images/alovera.jpg')); ?>"
                alt="Aloe vera leaves">

            <span class="ev-ing-image-number">01 / 06</span>

            <div class="ev-ing-image-caption">
                <span>THE HEART OF EVALORÉ</span>
                <strong>Aloe Vera</strong>
            </div>
        </div>

        <div class="ev-ing-feature-content">
            <span class="ev-ing-kicker">01 — OUR SIGNATURE INSPIRATION</span>

            <h2>Aloe Vera <em>| At the Heart of Evaloré</em></h2>

            <div class="ev-ing-gold-line"></div>

            <p>
                The green leaves in our logo represent aloe vera, a key
                ingredient in our product philosophy.
            </p>

            <p>
                Widely used for its skin-conditioning qualities, aloe vera
                connects our identity to nature-inspired care.
            </p>

            <div class="ev-ing-feature-note">
                <span>WHY IT MATTERS TO US</span>
                <strong>A symbol of our connection to nature.</strong>
            </div>
        </div>

    </section>


    <!-- OLIVE OIL -->
    <section class="ev-ing-feature ev-ing-reverse ev-ing-olive">

        <div class="ev-ing-feature-image">
            <img src="<?php echo e(asset('assets/images/oil.jpg')); ?>"
                alt="Olive oil">

            <span class="ev-ing-image-number">02 / 06</span>

            <div class="ev-ing-image-caption">
                <span>A MEDITERRANEAN TRADITION</span>
                <strong>Olive Oil</strong>
            </div>
        </div>

        <div class="ev-ing-feature-content">
            <span class="ev-ing-kicker">02 — A TIMELESS BEAUTY INGREDIENT</span>

            <h2>Olive Oil <em>| A Timeless Beauty Ingredient</em></h2>

            <div class="ev-ing-gold-line"></div>

            <p>
                Valued across Mediterranean beauty traditions, olive oil
                forms part of the base of our Moroccan Soap formulations.
            </p>

            <p>
                It supports a cleansing experience that leaves skin feeling
                cared for.
            </p>

            <div class="ev-ing-feature-note">
                <span>WHERE YOU'LL FIND IT</span>
                <strong>Our Moroccan Soap Collection</strong>
            </div>
        </div>

    </section>


    <!-- VITAMIN E -->
    <section class="ev-ing-vitamin">
        <div class="ev-ing-vitamin-image">
            <img src="<?php echo e(asset('assets/images/vitamin_e.jpg')); ?>"
                alt="Vitamin E ingredient">

            <div class="ev-ing-vitamin-image-caption">
                <span>03 / 06</span>
                <strong>A SKINCARE ESSENTIAL</strong>
            </div>
        </div>

        <div class="ev-ing-vitamin-content">
            <span class="ev-ing-kicker">03 — SKIN-CONDITIONING CARE</span>

            <h2>Vitamin E <em>| A Skincare Essential</em></h2>

            <div class="ev-ing-gold-line"></div>

            <p>
                Tocopheryl Acetate, a vitamin E derivative, is used in
                our Moroccan Soaps as part of their skin-conditioning
                ingredient blend.
            </p>

            <div class="ev-ing-scientific-name">
                <span>INGREDIENT NAME</span>
                <strong>Tocopheryl Acetate</strong>
            </div>
        </div>
    </section>

    <!-- CLOSING -->
    <section class="ev-ing-closing">
        <div class="ev-ing-closing-overlay"></div>

        <div class="ev-ing-closing-content">
            <span class="ev-ing-kicker">THE EVALORÉ APPROACH</span>

            <h2>
                Thoughtfully considered.<br>
                <em>Inspired by nature.</em>
            </h2>

            <div class="ev-ing-closing-line"></div>

            <p>
                Every ingredient is part of a bigger story.
                Discover the collection inspired by nature and tradition.
            </p>

            <a href="<?php echo e(url('/#collection')); ?>" class="ev-ing-closing-link">
                EXPLORE OUR COLLECTION <span>→</span>
            </a>

        </div>
    </section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Windows.10\Desktop\My first baby\clients\2_Evalore\evalore-landing\evalore\resources\views/our-ingredients.blade.php ENDPATH**/ ?>