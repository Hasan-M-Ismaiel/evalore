<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<title><?php echo $__env->yieldContent('title', 'Evalore'); ?></title>
<meta name="description" content="<?php echo $__env->yieldContent('meta_description', ''); ?>">

<!-- Favicon -->
<link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/icons/favicon.png')); ?>">
<link rel="apple-touch-icon" href="<?php echo e(asset('assets/images/icons/favicon.png')); ?>">

<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

<!-- css for the pages -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/our-story.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/our-ingredients.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/our-philosophy.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/our-products.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/faq.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/first-collection.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/footer.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/hero.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/made-in-uae.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/more-products.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/nature.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/navbar.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/support.css')); ?>">

<?php /**PATH C:\Users\Windows.10\Desktop\My first baby\clients\2_Evalore\evalore-landing\evalore\resources\views/includes/head.blade.php ENDPATH**/ ?>