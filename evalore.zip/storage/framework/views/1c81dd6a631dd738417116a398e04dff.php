<!-- EVALORE NAVBAR -->
<nav class="evalore-navbar" id="ftco-navbar">
    <div class="container">

        <!-- Brand -->
        <a class="evalore-brand" href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('assets/images/logo.png')); ?>"
                alt="Evaloré">
        </a>

        <!-- Mobile Toggle -->
        <button class="evalore-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#evalore-nav"
            aria-controls="evalore-nav"
            aria-expanded="false"
            aria-label="Toggle navigation">

            <span></span>
            <span></span>
            <span></span>
        </button>

        <!-- Navigation -->
        <div class="navbar-collapse" id="evalore-nav">

            <ul class="evalore-nav-links">

                <li>
                    <a href="<?php echo e(url('/')); ?>" class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">Home</a>
                </li>

                <li class="evalore-dropdown">
                    <a href="#" class="dropdown-trigger <?php echo e(request()->routeIs('our-products') ? 'active' : ''); ?>">
                        Our Products
                        <span class="fa fa-angle-down"></span>
                    </a>

                    <div class="evalore-dropdown-menu">
                        <a href="<?php echo e(url('/#collection')); ?>">
                            Moroccan Soap
                        </a>
                    </div>
                </li>
                
                <!-- <li>
                    <a href=" " class="<?php echo e(request()->routeIs('our-story') ? 'active' : ''); ?>">Our Story</a>
                </li> -->

                <li>
                    <a href="<?php echo e(url('/#where-to-buy')); ?>">Where To Buy</a>
                </li>

                <li>
                    <a href="<?php echo e(url('/#contact')); ?>">Support</a>
                </li>

            </ul>

        </div>
    </div>
</nav><?php /**PATH C:\Users\Windows.10\Desktop\My first baby\clients\2_Evalore\evalore-landing\evalore\resources\views/includes/navbar.blade.php ENDPATH**/ ?>