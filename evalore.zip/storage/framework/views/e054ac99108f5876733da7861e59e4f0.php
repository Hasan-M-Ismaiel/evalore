<section class="evalore-divider"
    style="background-image: url('<?php echo e(asset('assets/images/bg_1.webp')); ?>');">
</section><?php /**PATH C:\Users\Windows.10\Desktop\My first baby\clients\2_Evalore\evalore-landing\evalore\resources\views/includes/sections/image-section.blade.php ENDPATH**/ ?>