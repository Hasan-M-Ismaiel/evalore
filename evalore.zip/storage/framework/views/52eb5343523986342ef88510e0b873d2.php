<!DOCTYPE html>
<html lang="en">

<head>
    <title>Evalore' | Beauty care</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/open-iconic-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/aos.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/ionicons.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.timepicker.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/icomoon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

    <!-- for the new template -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/clear.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/common.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/carouFredSel.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/prettyPhoto.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/sm-clean.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style_.css')); ?>">


    <!-- Third template CTA -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style__.css')); ?>">

    <!-- Fouth template Inspired by nature. Selected with care. -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style____.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive____.css')); ?>">

    <!-- css for the pages -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/our-story.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/our-ingredients.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/our-philosophy.css')); ?>">

</head>

<body>

    <!-- EVALORE NAVBAR -->
    <nav class="evalore-navbar" id="ftco-navbar">
        <div class="container">

            <!-- Brand -->
            <a class="evalore-brand" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('assets/images/logo.png')); ?>"
                    alt="Evaloré">
            </a>

            <!-- Mobile Toggle -->
            <button class="evalore-toggler"
                type="button"
                data-toggle="collapse"
                data-target="#evalore-nav"
                aria-controls="evalore-nav"
                aria-expanded="false"
                aria-label="Toggle navigation">

                <span></span>
                <span></span>
                <span></span>
            </button>

            <!-- Navigation -->
            <div class="navbar-collapse" id="evalore-nav">

                <ul class="evalore-nav-links">

                    <li>
                        <a href="<?php echo e(url('/')); ?>" class="active">Home</a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('our-story')); ?>">Our Story</a>
                    </li>

                    <li class="evalore-dropdown">
                        <a href="<?php echo e(url('/#collection')); ?>" class="dropdown-trigger">
                            Our Products
                            <span class="fa fa-angle-down"></span>
                        </a>

                        <div class="evalore-dropdown-menu">
                            <a href="<?php echo e(route('products.moroccan-soap')); ?>">
                                Moroccan Soap
                            </a>
                        </div>
                    </li>

                    <li>
                        <a href="<?php echo e(route('our-ingredients')); ?>">Our Ingredients</a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('our-philosophy')); ?>">Our Philosophy</a>
                    </li>

                    <li>
                        <a href="<?php echo e(url('/#where-to-buy')); ?>">Where To Buy</a>
                    </li>

                    <li>
                        <a href="<?php echo e(url('/#contact')); ?>">Support</a>
                    </li>

                </ul>

            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="evalore-hero" id="top">

        <div class="evalore-hero-image"
            style="background-image: url('<?php echo e(asset('assets/images/hero-evalore.jpg')); ?>');">
        </div>

        <div class="evalore-hero-overlay"></div>

        <div class="container">
            <div class="evalore-hero-content">

                <span class="hero-eyebrow">
                    THE ART OF EVERYDAY BEAUTY
                </span>

                <div class="hero-divider"></div>

                <h1>
                    Discover Beauty<br>
                    Inspired by Nature.
                </h1>

                <p>
                    Explore a world of cosmetics and skincare where botanical
                    inspiration meets thoughtful formulation and elegant design.
                    From everyday essentials to luxurious body-care rituals,
                    Evaloré celebrates beauty in its many forms.
                </p>

                <div class="hero-actions">

                    <a href="#collection" class="hero-btn hero-btn-primary">
                        Explore Our Collection
                        <span class="fa fa-long-arrow-right"></span>
                    </a>

                    <a href="#story" class="hero-btn hero-btn-outline">
                        Discover Our Story
                    </a>

                </div>

                <div class="hero-bottom-note">
                    <span></span>
                    THOUGHTFUL INGREDIENTS · BEAUTIFUL EXPERIENCES
                </div>

            </div>
        </div>

        <div class="hero-side-label">
            EVALORÉ — BEAUTY & CARE
        </div>

    </section>

    <!-- Nature at the Heart of Beauty -->
    <section class="evalore-nature-section" id="story">
        <div class="container-fluid">
            <div class="row no-gutters align-items-stretch">

                <!-- Image -->
                <div class="col-lg-6">
                    <div class="evalore-nature-image">
                        <img src="<?php echo e(asset('assets/images/nature.jpg')); ?>"
                            alt="Nature-inspired beauty and botanical ingredients">

                        <div class="nature-image-caption">
                            <span>INSPIRED BY NATURE</span>
                            <div></div>
                            <p>Beauty begins with nature.</p>
                        </div>
                    </div>
                </div>

                <!-- Content -->
                <div class="col-lg-6">
                    <div class="evalore-nature-content">

                        <span class="nature-eyebrow">
                            <span></span>
                            OUR STORY & INSPIRATION
                        </span>

                        <h2>
                            Nature is more than our inspiration.
                            <em>It is part of our identity.</em>
                        </h2>

                        <div class="nature-divider"></div>

                        <p class="nature-description">
                            The aloe vera leaves in our logo reflect the important
                            role of this ingredient in our products.
                        </p>

                        <p class="nature-description">
                            Alongside olive oil, vitamin E and selected botanical
                            extracts, aloe vera is part of our approach to creating
                            enjoyable beauty and self-care experiences.
                        </p>

                        <div class="nature-ingredients">
                            <div>
                                <span>01</span>
                                <p>Aloe Vera</p>
                            </div>
                            <div>
                                <span>02</span>
                                <p>Olive Oil</p>
                            </div>
                            <div>
                                <span>03</span>
                                <p>Vitamin E</p>
                            </div>
                            <div>
                                <span>04</span>
                                <p>Botanical Extracts</p>
                            </div>
                        </div>

                        <div class="nature-signature">
                            <span>Thoughtful ingredients.</span>
                            <span>Beautiful experiences.</span>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Ingredient Highlight -->
    <section class="evalore-ingredients-section" id="why-evalore">
        <div class="container">
            <div class="row align-items-center">

                <!-- Text -->
                <div class="col-lg-5">
                    <div class="evalore-ingredients-content">

                        <span class="ingredients-eyebrow">
                            <span></span>
                            THE ELEMENTS OF BEAUTY
                        </span>

                        <h2>
                            Inspired by nature.
                            <em>Selected with care.</em>
                        </h2>

                        <div class="ingredients-divider"></div>

                        <p>
                            From aloe vera and olive oil to vitamin E and
                            distinctive botanical extracts, discover the
                            ingredients behind our first collection and the
                            philosophy shaping Evaloré.
                        </p>

                        <p>
                            Every ingredient has a purpose in our approach
                            to thoughtful beauty and everyday self-care.
                        </p>

                        <a href="#collection" class="ingredients-link">
                            <span>Explore Our Ingredients</span>
                            <span class="fa fa-long-arrow-right"></span>
                        </a>

                        <div class="ingredients-signature">
                            Thoughtful ingredients. Beautiful experiences.
                        </div>

                    </div>
                </div>

                <!-- Ingredient Images -->
                <div class="col-lg-7">
                    <div class="evalore-ingredients-gallery">

                        <div class="ingredient-card ingredient-card-large">
                            <img src="<?php echo e(asset('assets/images/botanical.jpg')); ?>"
                                alt="Botanical extracts">
                            <div class="ingredient-overlay">
                                <span>01 / BOTANICALS</span>
                                <h3>Botanical Extracts</h3>
                            </div>
                        </div>

                        <div class="ingredient-card ingredient-card-large">
                            <img src="<?php echo e(asset('assets/images/vitamin_e.jpg')); ?>"
                                alt="Vitamin E">
                            <div class="ingredient-overlay">
                                <span>02 / NOURISH</span>
                                <h3>Vitamin E</h3>
                            </div>
                        </div>

                        <div class="ingredient-card ingredient-card-large">
                            <img src="<?php echo e(asset('assets/images/oil.jpg')); ?>"
                                alt="Olive oil">
                            <div class="ingredient-overlay">
                                <span>03 / NATURAL CARE</span>
                                <h3>Olive Oil</h3>
                            </div>
                        </div>

                        <div class="ingredient-card ingredient-card-large">
                            <img src="<?php echo e(asset('assets/images/alovera.jpg')); ?>"
                                alt="Aloe vera">
                            <div class="ingredient-overlay">
                                <span>04 / BOTANICAL CARE</span>
                                <h3>Aloe Vera</h3>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- EVALORE - FIRST COLLECTION -->
    <section class="evalore-collection-section" id="collection">

        <div class="container">

            <!-- Heading -->
            <div class="evalore-collection-heading">

                <span class="collection-eyebrow">
                    <span></span>
                    THE FIRST CHAPTER
                    <span></span>
                </span>

                <h2>
                    The Evaloré Luxury
                    <em>Moroccan Bath Collection</em>
                </h2>

                <p>
                    Inspired by timeless Moroccan beauty traditions,
                    our first collection brings a luxurious bathing ritual
                    into the comfort of home.
                </p>

                <div class="collection-heading-note">
                    THREE SIGNATURE EXPRESSIONS. ONE BEAUTIFUL RITUAL.
                </div>

            </div>

            <!-- Product Cards -->
            <div class="row evalore-product-row">

                <!-- Blue Nila -->
                <div class="col-lg-4 col-md-6">
                    <div class="evalore-product-card">

                        <div class="product-image">
                            <img src="<?php echo e(asset('assets/images/hero-2.jpeg')); ?>"
                                alt="Evaloré Blue Nila Moroccan Bath Set">

                            <span class="product-number">01</span>

                            <div class="product-image-label">
                                BLUE NILA
                            </div>
                        </div>

                        <div class="product-info">

                            <span class="product-category">
                                THE BLUE NILA COLLECTION
                            </span>

                            <h3>Blue Nila</h3>

                            <p>
                                A Moroccan bath set inspired by Blue Nila,
                                bringing together Moroccan soap, body serum,
                                and a loofah for your at-home bathing ritual.
                            </p>

                            <div class="product-includes">
                                <span>Soap</span>
                                <span>Body Serum</span>
                                <span>Loofah</span>
                            </div>

                            <a href="https://www.amazon.ae/Evalore-Moroccan-Black-Soap-Kit/dp/B0H3KSWNPF/ref=sr_1_36?th=1"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="product-shop-link">
                                <span>Discover on Amazon UAE</span>
                                <span class="fa fa-long-arrow-right"></span>
                            </a>

                        </div>
                    </div>
                </div>

                <!-- Aker Fassi -->
                <div class="col-lg-4 col-md-6">
                    <div class="evalore-product-card">

                        <div class="product-image">
                            <img src="<?php echo e(asset('assets/images/hero-1_.jpeg')); ?>"
                                alt="Evaloré Aker Fassi Moroccan Bath Set">

                            <span class="product-number">02</span>

                            <div class="product-image-label">
                                AKER FASSI
                            </div>
                        </div>

                        <div class="product-info">

                            <span class="product-category">
                                THE AKER FASSI COLLECTION
                            </span>

                            <h3>Aker Fassi</h3>

                            <p>
                                Inspired by the traditional Moroccan
                                ingredient Aker Fassi, this set combines
                                Moroccan soap, body serum, and a loofah
                                in one collection.
                            </p>

                            <div class="product-includes">
                                <span>Soap</span>
                                <span>Body Serum</span>
                                <span>Loofah</span>
                            </div>

                            <a href="https://www.amazon.ae/Evalore-Moroccan-Black-Soap-Kit/dp/B0H3L65PCW/ref=sr_1_36"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="product-shop-link">
                                <span>Discover on Amazon UAE</span>
                                <span class="fa fa-long-arrow-right"></span>
                            </a>

                        </div>
                    </div>
                </div>

                <!-- Emarati Sidr -->
                <div class="col-lg-4 col-md-6">
                    <div class="evalore-product-card">

                        <div class="product-image">
                            <img src="<?php echo e(asset('assets/images/hero-3.jpeg')); ?>"
                                alt="Evaloré Emarati Sidr Moroccan Bath Set">

                            <span class="product-number">03</span>

                            <div class="product-image-label">
                                EMARATI SIDR
                            </div>
                        </div>

                        <div class="product-info">

                            <span class="product-category">
                                THE EMARATI SIDR COLLECTION
                            </span>

                            <h3>Emarati Sidr</h3>

                            <p>
                                A Moroccan bath set inspired by Sidr,
                                bringing together soap, body serum, and
                                a loofah for a complete at-home bathing routine.
                            </p>

                            <div class="product-includes">
                                <span>Soap</span>
                                <span>Body Serum</span>
                                <span>Loofah</span>
                            </div>

                            <a href="https://www.amazon.ae/Evalore-Moroccan-Black-Soap-Kit/dp/B0H3L81TK2/ref=sr_1_36?th=1"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="product-shop-link">
                                <span>Discover on Amazon UAE</span>
                                <span class="fa fa-long-arrow-right"></span>
                            </a>

                        </div>
                    </div>
                </div>

            </div>

            <!-- Bottom Note -->
            <div class="collection-bottom-note">
                <span>THE ART OF THE MOROCCAN BATH RITUAL</span>
                <span class="collection-bottom-line"></span>
                <span>EVALORÉ</span>
            </div>

        </div>
    </section>

    <!-- Start a new Section horizontal -->
    <section class="ftco-section ftco-counter img" id="section-counter" style="background-image: url('<?php echo e(asset('assets/images/bg_1.webp')); ?>');" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row d-md-flex align-items-center justify-content-end">
            </div>
        </div>
    </section>

    <!-- More Beauty Is on the Way -->
    <section class="evalore-coming-section">
        <div class="container">
            <div class="evalore-coming-content">

                <div class="coming-label">
                    <span class="coming-dot"></span>
                    Coming Soon
                </div>

                <span class="evalore-eyebrow">A BEAUTIFUL JOURNEY AHEAD</span>

                <h2>More Beauty<br>Is on the Way.</h2>

                <div class="coming-divider"></div>

                <p class="coming-intro">
                    Our journey has just begun.
                </p>

                <p class="coming-description">
                    The Moroccan Bath Collection is the first chapter in a growing
                    Evaloré beauty portfolio. We look forward to introducing more
                    skincare, body care and hair care products, all guided by the
                    same focus on ingredients, quality and everyday elegance.
                </p>

                <p class="coming-signature">
                    New collections. New experiences.<br>
                    The same commitment to beauty.
                </p>

            </div>

            <div class="coming-decoration">
                <span class="decoration-letter">E</span>
                <span class="decoration-text">EVALORÉ · BEAUTY & CARE</span>
            </div>
        </div>
    </section>

    <!-- Made in the UAE -->
    <section class="evalore-uae-section" id="philosophy">
        <div class="container">
            <div class="row no-gutters align-items-stretch">

                <div class="col-lg-6">
                    <div class="uae-image">
                        <img src="<?php echo e(asset('assets/images/uae.jpg')); ?>"
                            alt="Evaloré – Developed and manufactured in the UAE">

                        <div class="uae-image-overlay">
                            <span>PROUDLY DEVELOPED & MANUFACTURED</span>
                            <h3>Made in the UAE</h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="uae-content">

                        <span class="uae-eyebrow">
                            OUR ORIGIN & COMMITMENT
                        </span>

                        <h2>Made in the UAE.<br>Inspired by the World.</h2>

                        <div class="uae-divider"></div>

                        <p>
                            Developed and manufactured in the United Arab Emirates,
                            Evaloré brings together local cosmetic manufacturing
                            expertise and inspiration from beauty traditions
                            around the world.
                        </p>

                        <p>
                            Our approach reflects a commitment to thoughtful
                            ingredients, quality and beautifully considered
                            everyday care.
                        </p>

                        <a href="#philosophy-details"
                            class="btn uae-button">
                            Our Philosophy & Quality
                            <span class="fa fa-long-arrow-right"></span>
                        </a>

                        <div class="uae-bottom-note">
                            <span class="fa fa-map-marker"></span>
                            Developed & Manufactured in the United Arab Emirates
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Where to Find Us / Support -->
    <section class="evalore-support-section" id="where-to-buy">
        <div class="container">

            <div class="support-heading">
                <span class="support-eyebrow">STAY CONNECTED WITH EVALORÉ</span>

                <h2>Discover. Experience. Connect.</h2>

                <p>
                    Discover our launch collection on Amazon UAE.
                    Have a question about Evaloré or our products?
                    Our customer care team is here to help.
                </p>
            </div>

            <div class="row justify-content-center">

                <!-- Where to Buy -->
                <div class="col-md-5">
                    <div class="support-card">

                        <div class="support-icon">
                            <span class="fa fa-shopping-bag"></span>
                        </div>

                        <span class="support-card-label">EXPLORE OUR COLLECTION</span>

                        <h3>Where to Buy</h3>

                        <p>
                            Discover our Moroccan Bath Collection
                            and explore our signature products on Amazon UAE.
                        </p>

                        <a href="#collection" class="support-button">
                            Where to Buy
                            <span class="fa fa-long-arrow-right"></span>
                        </a>

                    </div>
                </div>

                <!-- Customer Support -->
                <div class="col-md-5">
                    <div class="support-card">

                        <div class="support-icon">
                            <span class="fa fa-envelope-o"></span>
                        </div>

                        <span class="support-card-label">WE ARE HERE TO HELP</span>

                        <h3>Customer Support</h3>

                        <p>
                            Whether you have a question about our products,
                            ingredients or your experience with Evaloré,
                            we would love to hear from you.
                        </p>

                        <a href="#contact" class="support-button">
                            Contact Support
                            <span class="fa fa-long-arrow-right"></span>
                        </a>

                    </div>
                </div>

            </div>

            <div class="support-bottom">
                <span>Thoughtful ingredients.</span>
                <span class="support-separator">|</span>
                <span>Beautiful experiences.</span>
            </div>

        </div>
    </section>

    <!-- EVALORE FOOTER -->
    <footer class="ev-footer" id="contact">

        <div class="ev-footer-main">
            <div class="container">

                <div class="ev-footer-grid">

                    <!-- Brand -->
                    <div class="ev-footer-brand">

                        <a href="<?php echo e(url('/')); ?>" class="ev-footer-logo">
                            <img src="<?php echo e(asset('assets/images/logo.png')); ?>"
                                alt="Evaloré Logo">
                        </a>

                        <p>
                            Discover the beauty of Moroccan bathing rituals
                            with Evaloré. Explore our collection of Moroccan
                            black soap, body serums, and exfoliating essentials,
                            inspired by traditional care rituals.
                        </p>

                        <div class="ev-footer-social">
                            <span>FOLLOW OUR JOURNEY</span>

                            <div class="ev-social-links">
                                <a href="#" aria-label="Instagram">IG</a>
                                <a href="#" aria-label="Facebook">FB</a>
                                <a href="#" aria-label="LinkedIn">IN</a>
                            </div>
                        </div>

                    </div>

                    <!-- Explore -->
                    <div class="ev-footer-column">

                        <h3>Explore</h3>

                        <ul>
                            <li><a href="<?php echo e(url('/#story')); ?>">Our Story</a></li>
                            <li><a href="<?php echo e(url('/#why-evalore')); ?>">Our Ingredients</a></li>
                            <li><a href="<?php echo e(url('/#philosophy')); ?>">Our Philosophy</a></li>
                            <li><a href="<?php echo e(url('/#collection')); ?>">Our Collection</a></li>
                            <li><a href="<?php echo e(url('/#where-to-buy')); ?>">Where To Buy</a></li>
                        </ul>

                    </div>

                    <!-- Collections -->
                    <div class="ev-footer-column">

                        <h3>Our Collections</h3>

                        <ul>
                            <li>
                                <a href="https://www.amazon.ae/Evalore-Moroccan-Black-Soap-Kit/dp/B0H3KSWNPF/ref=sr_1_36?th=1"
                                    target="_blank" rel="noopener noreferrer">
                                    Blue Nila
                                </a>
                            </li>

                            <li>
                                <a href="https://www.amazon.ae/Evalore-Moroccan-Black-Soap-Kit/dp/B0H3L65PCW/ref=sr_1_36"
                                    target="_blank" rel="noopener noreferrer">
                                    Aker Fassi
                                </a>
                            </li>

                            <li>
                                <a href="https://www.amazon.ae/Evalore-Moroccan-Black-Soap-Kit/dp/B0H3L81TK2/ref=sr_1_36?th=1"
                                    target="_blank" rel="noopener noreferrer">
                                    Emarati Sidr
                                </a>
                            </li>

                            <li>
                                <a href="<?php echo e(route('products.moroccan-soap')); ?>">
                                    Moroccan Soap
                                </a>
                            </li>
                        </ul>

                    </div>

                    <!-- Discover -->
                    <div class="ev-footer-discover">

                        <span class="ev-footer-eyebrow">
                            THE EVALORÉ EXPERIENCE
                        </span>

                        <h3>
                            Beauty in every
                            <em>little ritual.</em>
                        </h3>

                        <p>
                            Thoughtful ingredients, timeless inspirations
                            and beautiful everyday experiences.
                        </p>

                        <a href="<?php echo e(url('/#collection')); ?>" class="ev-footer-cta">
                            Discover Our Collection
                            <span>&rarr;</span>
                        </a>

                    </div>

                </div>

            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="ev-footer-bottom">
            <div class="container">

                <div class="ev-footer-bottom-inner">

                    <p>
                        &copy; <?php echo e(date('Y')); ?> Evaloré.
                        All rights reserved.
                    </p>

                    <span class="ev-footer-motto">
                        THOUGHTFUL INGREDIENTS. BEAUTIFUL EXPERIENCES.
                    </span>

                    <a href="<?php echo e(url('/')); ?>" class="ev-footer-back">
                        BACK TO TOP <span>&uarr;</span>
                    </a>

                </div>

            </div>
        </div>

    </footer>

    <!-- loader -->
    <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
            <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
            <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00" />
        </svg></div>

    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.easing.1.3.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.stellar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.animateNumber.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.timepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scrollax.min.js')); ?>"></script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>

    <script src="<?php echo e(asset('assets/js/google-map.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>


    <!-- new template -->
    <!-- <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script> -->
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.sticky-kit.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.smartmenus.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.sticky.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.dryMenu.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/isotope.pkgd.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.carouFredSel-6.2.0-packed.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.mousewheel.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.touchSwipe.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.easing.1.3_.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/imagesloaded.pkgd.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.prettyPhoto.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/main_.js')); ?>"></script>


    <!-- for the CTA -->
    <script src="<?php echo e(asset('assets/js/main__.js')); ?>"></script>

    <!-- for the FAQs -->
    <script src="<?php echo e(asset('assets/js/main___.js')); ?>"></script>
</body>

</html><?php /**PATH C:\Users\Windows.10\Desktop\My first baby\clients\2_Evalore\evalore-landing\evalore\resources\views/welcome.blade.php ENDPATH**/ ?>