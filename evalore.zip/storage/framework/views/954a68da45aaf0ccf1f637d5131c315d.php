<!-- More Beauty Is on the Way -->
<section class="evalore-coming-section">
    <div class="container">
        <div class="evalore-coming-content">

            <div class="coming-label">
                <span class="coming-dot"></span>
                Coming Soon
            </div>

            <span class="evalore-eyebrow">A BEAUTIFUL JOURNEY AHEAD</span>

            <h2>More Beauty<br>Is on the Way.</h2>

            <div class="coming-divider"></div>

            <p class="coming-intro">
                Our journey has just begun.
            </p>

            <p class="coming-description">
                The Moroccan Bath Collection is the first chapter in a growing
                Evaloré beauty portfolio. We look forward to introducing more
                skincare, body care and hair care products, all guided by the
                same focus on ingredients, quality and everyday elegance.
            </p>

            <p class="coming-signature">
                New collections. New experiences.<br>
                The same commitment to beauty.
            </p>

        </div>

        <div class="coming-decoration">
            <img
                src="<?php echo e(asset('assets/images/seal-evalore.png')); ?>"
                alt="Evaloré Brand Seal"
                class="coming-brand-seal">
        </div>
    </div>
</section><?php /**PATH C:\Users\Windows.10\Desktop\My first baby\clients\2_Evalore\evalore-landing\evalore\resources\views/includes/sections/new-products-section.blade.php ENDPATH**/ ?>