


<?php $__env->startSection('content'); ?>

<main class="ev-products-page">

    <!-- HERO -->
    <section class="ev-products-hero">
        <div class="ev-products-hero-image"></div>
        <div class="ev-products-hero-overlay"></div>

        <div class="ev-products-hero-content">
            <span class="ev-products-eyebrow">THE EVALORÉ COLLECTION</span>
            <h1>Discover Our<br><em>Collections</em></h1>
            <p>
                Three botanical-inspired rituals, celebrating the beauty
                of the Moroccan bath tradition.
            </p>
            <a href="#ev-collections" class="ev-products-hero-link">
                EXPLORE THE COLLECTIONS <span>↓</span>
            </a>
        </div>

        <div class="ev-products-hero-number">01 — 03</div>
    </section>


    <!-- INTRODUCTION -->
    <section class="ev-products-intro">
        <div class="ev-products-intro-inner">
            <span class="ev-products-eyebrow">A RITUAL OF CARE</span>

            <h2>Beauty rituals, inspired<br>by <em>nature and tradition.</em></h2>

            <p>
                Discover the Evaloré collection. Our first launch celebrates
                the Moroccan bath tradition through three botanical-inspired
                rituals. Select a collection to explore its ingredients,
                benefits, instructions and purchasing options.
            </p>

            <div class="ev-products-intro-line"></div>
        </div>
    </section>


    <!-- COLLECTIONS -->
    <section class="ev-collections" id="ev-collections">

        <!-- AKER FASSI -->
        <article class="ev-product-collection ev-collection-aker" id="aker-fassi">

            <div class="ev-collection-visual">
                <img src="<?php echo e(asset('assets/images/hero-1_.jpeg')); ?>"
                     alt="Evaloré Aker Fassi Moroccan Bath Collection">

                <div class="ev-collection-image-caption">
                    <span>01 / THE COLLECTION</span>
                    <strong>AKER FASSI</strong>
                </div>
            </div>

            <div class="ev-collection-content">
                <span class="ev-products-eyebrow">THE RADIANCE COLLECTION</span>

                <h2>Aker Fassi</h2>
                <h3>Inspired by tradition. Created for radiance.</h3>

                <p class="ev-collection-description">
                    Discover a beauty ritual inspired by Aker Fassi and
                    Moroccan botanical beauty practices. Our Aker Fassi
                    collection brings together Moroccan Soap and a matching
                    Body Serum for a luxurious body-care experience.
                </p>

                <div class="ev-product-detail">
                    <div class="ev-product-detail-heading">
                        <span>01</span>
                        <div>
                            <h4>Moroccan Soap — Aker Fassi</h4>
                            <small>350 ml</small>
                        </div>
                    </div>

                    <p>
                        Enriched with olive oil, pomegranate peel extract,
                        aloe vera and vitamin E, this soap gently cleanses
                        the skin and helps enhance its natural radiance.
                    </p>

                    <div class="ev-benefits">
                        <span>Gently cleanses</span>
                        <span>Natural-looking radiance</span>
                        <span>Soft & refreshed skin</span>
                    </div>
                </div>

                <div class="ev-product-detail">
                    <div class="ev-product-detail-heading">
                        <span>02</span>
                        <div>
                            <h4>Aker Fassi Body Serum</h4>
                            <small>60 ml</small>
                        </div>
                    </div>

                    <p>
                        Complete the ritual with the matching Body Serum,
                        designed as the finishing step in the collection.
                    </p>

                    <p class="ev-pending-note">
                        Specific serum benefits and full ingredient details
                        will be added following formula verification.
                    </p>
                </div>

                <div class="ev-how-to">
                    <span class="ev-small-label">THE RITUAL</span>
                    <p>
                        Apply Moroccan Soap to damp skin, gently massage
                        with a loofah, leave for 3–5 minutes, then rinse
                        thoroughly. Follow with the matching serum
                        according to its label.
                    </p>
                </div>

                <a class="ev-amazon-link"
                   href="https://www.amazon.ae/Evalore-Moroccan-Black-Soap-Kit/dp/B0H3L65PCW/ref=sr_1_36"
                   target="_blank" rel="noopener noreferrer">
                    FIND AKER FASSI ON AMAZON UAE
                    <span>↗</span>
                </a>

                <details class="ev-ingredient-details">
                    <summary>Explore ingredients & product information</summary>

                    <div class="ev-ingredient-content">
                        <h5>Featured Ingredients</h5>
                        <ul>
                            <li>Olea Europaea Fruit Oil</li>
                            <li>Punica Granatum Peel Extract</li>
                            <li>Aloe Barbadensis Leaf Extract</li>
                            <li>Tocopheryl Acetate</li>
                        </ul>

                        <h5>Full Soap Ingredients (INCI)</h5>
                        <p>
                            Aqua, Olea Europaea Fruit Oil, Sodium Hydroxide,
                            Potassium Hydroxide, Parfum, Punica Granatum
                            Peel Extract, Tocopheryl Acetate, Aloe
                            Barbadensis Leaf Extract, CI 17200.
                        </p>

                        <h5>Product Warnings</h5>
                        <p>
                            For external use only. Avoid contact with eyes.
                            Discontinue use if irritation occurs. Keep out
                            of reach of children. Store in a cool, dry place.
                        </p>

                        <p class="ev-serum-disclosure">
                            Body Serum ingredient information is pending
                            formula verification.
                        </p>
                    </div>
                </details>

            </div>
        </article>


        <!-- BLUE NILA -->
        <article class="ev-product-collection ev-collection-blue" id="blue-nila">

            <div class="ev-collection-visual">
                <img src="<?php echo e(asset('assets/images/hero-2.jpeg')); ?>"
                     alt="Evaloré Blue Nila Moroccan Bath Collection">

                <div class="ev-collection-image-caption">
                    <span>02 / THE COLLECTION</span>
                    <strong>BLUE NILA</strong>
                </div>
            </div>

            <div class="ev-collection-content">
                <span class="ev-products-eyebrow">THE LUMINOSITY COLLECTION</span>

                <h2>Blue Nila</h2>
                <h3>Inspired by Moroccan beauty. Designed for radiance.</h3>

                <p class="ev-collection-description">
                    Discover the beauty of Blue Nila, an ingredient associated
                    with traditional Moroccan beauty rituals. This collection
                    combines Moroccan Soap with a matching Body Serum.
                </p>

                <div class="ev-product-detail">
                    <div class="ev-product-detail-heading">
                        <span>01</span>
                        <div>
                            <h4>Moroccan Soap — Blue Nila</h4>
                            <small>350 ml</small>
                        </div>
                    </div>

                    <p>
                        Made with olive oil and enriched with Blue Nila
                        extract, aloe vera and vitamin E, this soap gently
                        cleanses, leaving skin soft and naturally radiant.
                    </p>

                    <div class="ev-benefits">
                        <span>Gently cleanses & refreshes</span>
                        <span>Helps improve the appearance of uneven tone</span>
                        <span>Soft-feeling skin</span>
                    </div>
                </div>

                <div class="ev-product-detail">
                    <div class="ev-product-detail-heading">
                        <span>02</span>
                        <div>
                            <h4>Blue Nila Body Serum</h4>
                            <small>60 ml</small>
                        </div>
                    </div>

                    <p>
                        Complete your ritual with the complementary Body
                        Serum, created as the finishing step in the collection.
                    </p>

                    <p class="ev-pending-note">
                        Specific serum benefits and full ingredient details
                        will be added following formula verification.
                    </p>
                </div>

                <div class="ev-how-to">
                    <span class="ev-small-label">THE RITUAL</span>
                    <p>
                        Apply Moroccan Soap to damp skin, massage gently
                        with a loofah, leave for 3–5 minutes and rinse
                        thoroughly. Follow with the matching serum
                        according to its label.
                    </p>
                </div>

                <a class="ev-amazon-link"
                   href="https://www.amazon.ae/Evalore-Moroccan-Black-Soap-Kit/dp/B0H3KSWNPF/ref=sr_1_36?th=1"
                   target="_blank" rel="noopener noreferrer">
                    FIND BLUE NILA ON AMAZON UAE
                    <span>↗</span>
                </a>

                <details class="ev-ingredient-details">
                    <summary>Explore ingredients & product information</summary>

                    <div class="ev-ingredient-content">
                        <h5>Featured Ingredients</h5>
                        <ul>
                            <li>Olea Europaea Fruit Oil</li>
                            <li>Indigofera Tinctoria Leaf Extract</li>
                            <li>Aloe Barbadensis Leaf Extract</li>
                            <li>Tocopheryl Acetate</li>
                        </ul>

                        <h5>Full Soap Ingredients (INCI)</h5>
                        <p>
                            Aqua, Olea Europaea Fruit Oil, Sodium Hydroxide,
                            Potassium Hydroxide, Parfum, Indigofera Tinctoria
                            Leaf Extract, Tocopheryl Acetate, Aloe Barbadensis
                            Leaf Extract, CI 69825.
                        </p>

                        <h5>Product Warnings</h5>
                        <p>
                            For external use only. Avoid contact with eyes.
                            Discontinue use if irritation occurs. Keep out
                            of reach of children. Store in a cool, dry place.
                        </p>

                        <p class="ev-serum-disclosure">
                            Body Serum ingredient information is pending
                            formula verification.
                        </p>
                    </div>
                </details>

            </div>
        </article>


        <!-- EMARATI SIDR -->
        <article class="ev-product-collection ev-collection-sidr" id="emarati-sidr">

            <div class="ev-collection-visual">
                <img src="<?php echo e(asset('assets/images/hero-3.jpeg')); ?>"
                     alt="Evaloré Emarati Sidr Moroccan Bath Collection">

                <div class="ev-collection-image-caption">
                    <span>03 / THE COLLECTION</span>
                    <strong>EMARATI SIDR</strong>
                </div>
            </div>

            <div class="ev-collection-content">
                <span class="ev-products-eyebrow">THE BALANCE COLLECTION</span>

                <h2>Emarati Sidr</h2>
                <h3>Rooted in heritage. Inspired by nature.</h3>

                <p class="ev-collection-description">
                    Discover a distinctive ritual inspired by Sidr, a
                    botanical ingredient with a longstanding place in
                    Arabian heritage. The collection combines regional
                    inspiration with the Moroccan bathing tradition.
                </p>

                <div class="ev-product-detail">
                    <div class="ev-product-detail-heading">
                        <span>01</span>
                        <div>
                            <h4>Moroccan Soap — Emarati Sidr</h4>
                            <small>350 ml</small>
                        </div>
                    </div>

                    <p>
                        Infused with Sidr leaf extract, olive oil, aloe vera
                        and vitamin E, this soap gently cleanses and helps
                        maintain balanced, healthy-looking skin.
                    </p>

                    <div class="ev-benefits">
                        <span>Gently cleanses</span>
                        <span>Helps soothe & refresh</span>
                        <span>Soft & comfortable skin</span>
                    </div>
                </div>

                <div class="ev-product-detail">
                    <div class="ev-product-detail-heading">
                        <span>02</span>
                        <div>
                            <h4>Emarati Sidr Body Serum</h4>
                            <small>60 ml</small>
                        </div>
                    </div>

                    <p>
                        Complete the ritual with the matching Body Serum,
                        designed as the finishing step in the collection.
                    </p>

                    <p class="ev-pending-note">
                        Specific serum benefits and full ingredient details
                        will be added following formula verification.
                    </p>
                </div>

                <div class="ev-how-to">
                    <span class="ev-small-label">THE RITUAL</span>
                    <p>
                        Apply Moroccan Soap to damp skin, massage gently
                        with a loofah, leave for 3–5 minutes, then rinse
                        thoroughly. Follow with the matching serum
                        according to its label.
                    </p>
                </div>

                <a class="ev-amazon-link"
                   href="https://www.amazon.ae/Evalore-Moroccan-Black-Soap-Kit/dp/B0H3L81TK2/ref=sr_1_36?th=1"
                   target="_blank" rel="noopener noreferrer">
                    FIND EMARATI SIDR ON AMAZON UAE
                    <span>↗</span>
                </a>

                <details class="ev-ingredient-details">
                    <summary>Explore ingredients & product information</summary>

                    <div class="ev-ingredient-content">
                        <h5>Featured Ingredients</h5>
                        <ul>
                            <li>Ziziphus Spina-Christi Leaf Extract</li>
                            <li>Olea Europaea Fruit Oil</li>
                            <li>Aloe Barbadensis Leaf Extract</li>
                            <li>Tocopheryl Acetate</li>
                        </ul>

                        <h5>Full Soap Ingredients (INCI)</h5>
                        <p>
                            Aqua, Olea Europaea Fruit Oil, Sodium Hydroxide,
                            Potassium Hydroxide, Parfum, Ziziphus Spina-Christi
                            Leaf Extract, Tocopheryl Acetate, Aloe Barbadensis
                            Leaf Extract, CI 42090, CI 19140.
                        </p>

                        <h5>Product Warnings</h5>
                        <p>
                            For external use only. Avoid contact with eyes.
                            Discontinue use if irritation occurs. Keep out
                            of reach of children. Store in a cool, dry place.
                        </p>

                        <p class="ev-serum-disclosure">
                            Body Serum ingredient information is pending
                            formula verification.
                        </p>
                    </div>
                </details>

            </div>
        </article>

    </section>


    <!-- CLOSING -->
    <section class="ev-products-closing">
        <div class="ev-products-closing-inner">
            <span class="ev-products-eyebrow">THE EVALORÉ EXPERIENCE</span>

            <h2>A moment of care.<br><em>A ritual of your own.</em></h2>

            <p>
                Explore the collection and discover a beauty ritual
                inspired by nature, heritage and everyday elegance.
            </p>

            <a href="https://www.amazon.ae/s?k=Evalore+Moroccan+Black+Soap+Kit"
               target="_blank" rel="noopener noreferrer"
               class="ev-closing-link">
                EXPLORE EVALORÉ ON AMAZON UAE <span>↗</span>
            </a>
        </div>
    </section>

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Windows.10\Desktop\My first baby\clients\2_Evalore\evalore-landing\evalore\resources\views/our-products.blade.php ENDPATH**/ ?>